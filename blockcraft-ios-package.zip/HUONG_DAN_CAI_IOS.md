# Hướng dẫn cài BlockCraft lên iPhone (iOS)

Vì file `.ipa` iOS bắt buộc phải biên dịch bằng **Xcode trên macOS** và ký chứng chỉ Apple để iPhone cho cài, gói này cung cấp sẵn **2 cách** để bạn cài lên iPhone:

---

## Cách 1: Cài trực tiếp như App toàn màn hình (30 giây — Không cần Mac, không hết hạn 7 ngày)
1. Giải nén thư mục `www/` và đưa lên một host HTTPS miễn phí bất kỳ (ví dụ **GitHub Pages**, **Vercel**, hoặc **Netlify Drop** — chỉ cần kéo thả thư mục `www/`).
2. Mở link HTTPS đó bằng **Safari** trên iPhone.
3. Bấm nút **Chia sẻ (Share)** ở thanh dưới → chọn **Thêm vào Màn hình chính (Add to Home Screen)** → bấm **Thêm**.
4. Mở biểu tượng **BlockCraft** trên màn hình chính: game chạy toàn màn hình không thanh địa chỉ, hỗ trợ cảm biến Con quay (Gyro), lưu tiến trình IndexedDB và chơi offline qua Service Worker.

---

## Cách 2: Xuất file `BlockCraft-unsigned.ipa` thật bằng GitHub Actions (Miễn phí, không cần máy Mac)
1. Tạo một repository mới trên **GitHub** và đẩy toàn bộ nội dung gói này lên nhánh `main`.
2. Vào tab **Actions** trên GitHub → chọn workflow **Build BlockCraft iOS IPA** → bấm **Run workflow**.
3. Đợi ~3–5 phút để máy chủ macOS + Xcode của GitHub tự biên dịch xong, sau đó tải file **`BlockCraft-unsigned.ipa`** ở mục **Artifacts**.
4. Cài file `.ipa` vừa tải lên iPhone bằng **Sideloadly** (Windows/Mac), **AltStore** hoặc **SideStore** (đăng nhập Apple ID của bạn để tự ký và cài trực tiếp lên iPhone).
